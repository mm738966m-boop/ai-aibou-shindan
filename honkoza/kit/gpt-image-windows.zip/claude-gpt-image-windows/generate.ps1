param(
    [Parameter(Mandatory=$true)][string]$Prompt,
    [ValidateSet('gpt-image-2.5-flare','gpt-image-2.5-sunburst')][string]$Model='gpt-image-2.5-flare',
    [ValidateSet('1536x1024','1024x1536','1024x1024')][string]$Size='1536x1024',
    [switch]$Yes
)
$ErrorActionPreference = 'Stop'
$secretPath = Join-Path $HOME '.claude\gpt-image\openai-key.xml'
if (!(Test-Path $secretPath)) { throw 'API key missing. Run install.ps1 first.' }
$secure = Import-Clixml $secretPath
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try { $apiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
Write-Host "Model: $Model | Quality: high | Size: $Size | Count: 1"
Write-Host 'A paid OpenAI API image generation request will be sent.'
if (-not $Yes) { Write-Host 'Not sent. Add -Yes only after the user agreed to the cost.'; exit 0 }
$body = @{
    model=$Model
    prompt=$Prompt
    size=$Size
    quality='high'
    n=1
    output_format='png'
} | ConvertTo-Json -Depth 5
try {
    $result = Invoke-RestMethod -Method Post -Uri 'https://api.openai.com/v1/images/generations' -Headers @{Authorization="Bearer $apiKey"} -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) -ContentType 'application/json; charset=utf-8' -TimeoutSec 240
} finally { $apiKey = $null }
if (!$result.data -or !$result.data[0].b64_json) { throw 'No image returned. Check API usage/billing.' }
$folder = Join-Path (Get-Location).Path 'generated_images'
New-Item -ItemType Directory -Force -Path $folder | Out-Null
$name = "gpt-image_$(Get-Date -Format 'yyyyMMdd_HHmmss').png"
$path = Join-Path $folder $name
[IO.File]::WriteAllBytes($path, [Convert]::FromBase64String($result.data[0].b64_json))
Write-Host "IMAGE_PATH=$path" -ForegroundColor Green
