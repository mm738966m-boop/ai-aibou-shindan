Windows版 Claude Code × OpenAI画像生成 (高画質)

1. https://platform.openai.com/api-keys でAPIキーを取得し、課金/利用上限も設定。
2. ZIPを展開する。
3. 展開したフォルダでPowerShellを開き、以下を実行:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
4. APIキーを貼り付けてEnter（入力内容は非表示）。
5. Claude Codeを再起動。
6. Claude Codeの画面で入力:
   /gpt-image 新NISAの積立投資を大人っぽく解説する高級感のある日本語図解を作成
7. 「料金がかかります。作ってよいですか？」と聞かれたら「はい」。画像はカレントフォルダのgenerated_imagesに保存。

注意:
- OpenAI APIの料金はChatGPTの月額料金とは別。
- 自動リトライはありません。高画質 high で1回1枚だけ生成します。
- 料金はモデル・画像サイズ・トークン数によって変わります。料金表を確認してください。
