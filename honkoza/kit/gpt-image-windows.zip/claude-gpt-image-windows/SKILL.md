---
name: gpt-image
description: OpenAI高画質画像生成APIをClaude Codeから1枚ずつ呼び出し、Windows上のプロジェクトにPNGを保存する
argument-hint: "画像の説明（日本語OK）"
disable-model-invocation: true
---

ユーザーの画像生成依頼: $ARGUMENTS

Windows PowerShellで以下のスクリプトを実行してください。プロンプトは日本語のまま正確に渡してください。コマンドで引用符を安全に扱うため、可能ならClaude CodeのBashツールから PowerShell の引数渡しに適切にエスケープしてください。

実行の前に、ユーザーに「OpenAIの料金がかかります。高画質で1枚作ってよいですか？」と聞き、「はい」をもらってから実行する。

`powershell.exe -NoProfile -File "$HOME/.claude/gpt-image/generate.ps1" -Prompt "<依頼内容>" -Yes`

重要ルール:
- 使用する画像モデルは `gpt-image-2.5-flare`、品質は `high`、画像1枚をデフォルトとする。
- APIコスト発生を明示し、ユーザーの「はい」なしに -Yes を付けない。
- ユーザーの明示的な許可なしに再生成しない。
- エラーになった場合、黙って繰り返し呼び出さない。
- 出力された `IMAGE_PATH=` のパスを使って生成画像を参照し、必要なら Read ツールで確認する。
- APIキーの中身を表示・記録・送信しない。
- 引用符や改行を含む長いプロンプトは、一時ファイル経由など安全な方法で渡す。現状スクリプトは `-Prompt` を受け付ける。
