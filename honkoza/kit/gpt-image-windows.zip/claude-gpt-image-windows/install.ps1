$ErrorActionPreference = 'Stop'
$root = Join-Path $HOME '.claude\gpt-image'
$skill = Join-Path $HOME '.claude\skills\gpt-image'
New-Item -ItemType Directory -Force -Path $root, $skill | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'generate.ps1') (Join-Path $root 'generate.ps1') -Force
Copy-Item (Join-Path $PSScriptRoot 'SKILL.md') (Join-Path $skill 'SKILL.md') -Force
Write-Host 'OpenAI API key is required. The key will be encrypted for this Windows user using DPAPI.'
$key = Read-Host 'Paste OpenAI API key' -AsSecureString
if ($key.Length -lt 10) { throw 'API key appears invalid.' }
$key | Export-Clixml -Path (Join-Path $root 'openai-key.xml')
Write-Host "Installed. Restart Claude Code, then use: /gpt-image your image description" -ForegroundColor Green
Write-Host "Stored key: $root\openai-key.xml (Windows user-encrypted)"
