Mac版 Claude Code × OpenAI画像生成（高画質）

1. https://platform.openai.com/api-keys でAPIキーを作り、料金のチャージと上限を設定する
2. このZIPをダブルクリックして開く（ダウンロードフォルダに「claude-gpt-image-mac」ができる）
3. 「ターミナル」を開いて、次の文字を入れて return
   bash ~/Downloads/claude-gpt-image-mac/install.sh
4. APIキーを貼り付けて return（画面には表示されません）
5. Claude Code を一度閉じて、開き直す
6. Claude Code に入力する
   /gpt-image 新NISAの積立をやさしく伝える、明るい色のイラスト
7. 「料金がかかります。作ってよいですか？」と聞かれたら「はい」
   画像は、いま開いているフォルダの generated_images に保存されます

注意
- OpenAI APIの料金は、ChatGPTの月額料金とは別です
- 1回1枚、高画質で作ります。作り直すときも、毎回確認があります
