#!/bin/bash
# Mac版 Claude Code × OpenAI画像生成 の入れ方（ターミナルで実行）
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HOME/.claude/gpt-image" "$HOME/.claude/skills/gpt-image"
cp "$DIR/generate.sh" "$HOME/.claude/gpt-image/generate.sh"
chmod +x "$HOME/.claude/gpt-image/generate.sh"
cp "$DIR/SKILL.md" "$HOME/.claude/skills/gpt-image/SKILL.md"
echo ""
echo "OpenAIのAPIキーを貼り付けて、return を押してください（画面には表示されません）"
read -s KEY
echo ""
if [ ${#KEY} -lt 20 ]; then echo "キーが短すぎます。もう一度コピーしてやり直してください"; exit 1; fi
security add-generic-password -U -s claude-gpt-image -a openai -w "$KEY" >/dev/null
KEY=""
echo "入りました。キーはMacのキーチェーンに保管しました（このMacのあなただけが使えます）"
echo "Claude Code を一度閉じて開き直し、「/gpt-image 画像の説明」で使えます"
