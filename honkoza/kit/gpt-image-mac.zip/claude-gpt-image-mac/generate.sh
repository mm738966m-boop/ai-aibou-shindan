#!/bin/bash
# 使い方: generate.sh "画像の説明" --yes [--size 1536x1024|1024x1536|1024x1024]
YES=0; SIZE=1536x1024; MODEL=gpt-image-2.5-flare; PROMPT=""
while [ $# -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    --size) SIZE="$2"; shift ;;
    --model) MODEL="$2"; shift ;;
    *) PROMPT="$1" ;;
  esac; shift
done
if [ -z "$PROMPT" ]; then echo '使い方: generate.sh "画像の説明" --yes'; exit 1; fi
KEY=$(security find-generic-password -s claude-gpt-image -a openai -w 2>/dev/null) || { echo "APIキーが入っていません。先に install.sh を実行してください"; exit 1; }
echo "Model: $MODEL | Quality: high | Size: $SIZE | 1枚"
if [ "$YES" != 1 ]; then echo "OpenAIの料金がかかります。--yes を付けたときだけ送ります（今回は送っていません）"; exit 0; fi
TMP=$(mktemp -d)
osascript -l JavaScript -e 'function run(a){return JSON.stringify({model:a[0],prompt:a[1],size:a[2],quality:"high",n:1,output_format:"png"})}' "$MODEL" "$PROMPT" "$SIZE" > "$TMP/body.json"
curl -s --max-time 240 https://api.openai.com/v1/images/generations \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json; charset=utf-8" \
  --data-binary @"$TMP/body.json" -o "$TMP/res.json"
KEY=""
mkdir -p generated_images
OUT="$PWD/generated_images/gpt-image_$(date +%Y%m%d_%H%M%S).png"
osascript -l JavaScript -e 'ObjC.import("Foundation");function run(a){var s=$.NSString.stringWithContentsOfFileEncodingError(a[0],$.NSUTF8StringEncoding,null).js;var j=JSON.parse(s);if(!j.data||!j.data[0]||!j.data[0].b64_json){return "ERROR "+(j.error?j.error.message:"画像が返ってきませんでした。料金のチャージと上限を確かめてください")}var d=$.NSData.alloc.initWithBase64EncodedStringOptions(j.data[0].b64_json,0);d.writeToFileAtomically(a[1],true);return "IMAGE_PATH="+a[1]}' "$TMP/res.json" "$OUT"
rm -rf "$TMP"
