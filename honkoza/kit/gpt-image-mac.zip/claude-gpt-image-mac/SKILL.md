---
name: gpt-image
description: OpenAIの高画質画像生成APIをClaude Codeから1枚ずつ呼び出し、Macのプロジェクトフォルダに画像（PNG）を保存する
argument-hint: "画像の説明（日本語OK）"
disable-model-invocation: true
---

ユーザーの画像生成依頼: $ARGUMENTS

手順:
1. 依頼内容から、画像の説明（プロンプト）を整える。
2. 実行の前に、ユーザーに「OpenAIの料金がかかります。高画質で1枚作ってよいですか？」と聞き、「はい」をもらう。
3. 「はい」をもらったときだけ、次を実行する。

`bash "$HOME/.claude/gpt-image/generate.sh" "<画像の説明>" --yes`

大事な決まり:
- 画像のモデルは gpt-image-2.5-flare、品質は high、1回1枚。
- ユーザーの「はい」なしに --yes を付けない。作り直しも、そのたびに聞く。
- エラーのときは、黙って何度も呼び直さない。エラーの文をそのまま伝える。
- 出力された IMAGE_PATH= のパスの画像を Read で確かめてから、ユーザーに見せる。
- APIキーの中身を表示・記録・送信しない。
- 縦長は --size 1024x1536、正方形は --size 1024x1024 を付ける。
